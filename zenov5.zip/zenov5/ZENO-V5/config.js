require("./database/module")

//GLOBAL PAYMENT
global.storename = "𝐃𝐫𝐚𝐲𝐲𝐲"
global.dana = "-"
global.qris = "-"

// Simbol



// GLOBAL SETTING
global.owner = "𝐃𝐫𝐚𝐲𝐲𝐲"
global.namaown = "𝐃𝐫𝐚𝐲𝐗𝐃"
global.nomorbot = "6283151568511"
global.namaCreator = "𝐃𝐫𝐚𝐲𝐗𝐃"
global.autoJoin = false
global.antilink = false
global.versisc = '𝟓.𝟎.𝟎'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'

//JANGAN DIHAPUS/DIGANTI NANTI ERORR
var _0x4bbb19=_0x5efe;(function(_0x3f5cd9,_0x5f1fe3){var _0x2fb2b9=_0x5efe,_0x5901b9=_0x3f5cd9();while(!![]){try{var _0x1b960d=parseInt(_0x2fb2b9(0x19d))/0x1+-parseInt(_0x2fb2b9(0x196))/0x2+-parseInt(_0x2fb2b9(0x197))/0x3*(parseInt(_0x2fb2b9(0x191))/0x4)+parseInt(_0x2fb2b9(0x19b))/0x5+parseInt(_0x2fb2b9(0x19f))/0x6+-parseInt(_0x2fb2b9(0x19a))/0x7+parseInt(_0x2fb2b9(0x192))/0x8*(parseInt(_0x2fb2b9(0x199))/0x9);if(_0x1b960d===_0x5f1fe3)break;else _0x5901b9['push'](_0x5901b9['shift']());}catch(_0x322662){_0x5901b9['push'](_0x5901b9['shift']());}}}(_0x46a9,0x63da5),global[_0x4bbb19(0x198)]='â™¨ï¸Ž',global[_0x4bbb19(0x19e)]=_0x4bbb19(0x19c),global['linkyt']=_0x4bbb19(0x193),global['url']=_0x4bbb19(0x194),global[_0x4bbb19(0x195)]='https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L');function _0x5efe(_0x1b5aa2,_0x49232a){var _0x46a973=_0x46a9();return _0x5efe=function(_0x5efe12,_0x3fa000){_0x5efe12=_0x5efe12-0x191;var _0x211020=_0x46a973[_0x5efe12];return _0x211020;},_0x5efe(_0x1b5aa2,_0x49232a);}function _0x46a9(){var _0x22848f=['12592035FxyTPP','4653215xsVIJq','2366135PdUCOt','𝐙𝐄𝐍𝐎-𝐕𝟓','519856CVrZef','namabot','554376QNtwaU','3090200RRupnu','8DkEfpk','https://youtube.com/@drayyyxd','https://www.youtube.com/@drayyyxd','isLink','1276604AGsmZo','3IGKKLZ','simbol'];_0x46a9=function(){return _0x22848f;};return _0x46a9();}

//GLOBAL THUMB
global.codeInvite = ""
global.imageurl = 'https://g.top4top.io/p_3194iz70l0.jpg'
global.packname = "𝐙𝐞𝐧𝐨"
global.author = "𝐃𝐫𝐚𝐲𝐗𝐃"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})